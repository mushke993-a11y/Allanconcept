# Allan Concept — Graphic Designer Portfolio

A premium, responsive portfolio site for **Allan Concept** built with Next.js 14 (App Router), React, Tailwind CSS, Framer Motion and Supabase.

> **Design direction:** ink-black canvas with a coral → violet signature gradient, Space Grotesk display type, JetBrains Mono for eyebrows/labels, and a recurring "trimmed corner" motif (`cut-corner` utility class) on cards and buttons — a nod to a designer's cutting mat/print proof.

---

## ✅ What's fully built

- All 8 public pages: Home, Portfolio (+ project detail), Services, Pricing, About, Blog (+ post detail + comments), Testimonials, Contact
- Masonry portfolio grid with **category filter**, **search**, **lightbox preview**, and a dedicated project page
- Animated hero, animated counters, animated skill bars, auto-sliding testimonial carousel
- Contact form → `/api/contact` → Supabase `contact_submissions` table
- Blog comment form → Supabase `blog_comments` (held for approval)
- Newsletter signup (footer) → Supabase `newsletter_subscribers`
- Dark/light mode with persisted preference and reduced-motion support
- WhatsApp floating button, back-to-top button, cookie consent banner, custom loading animation, custom 404 page
- SEO: per-page metadata, Open Graph/Twitter cards, JSON-LD business schema, dynamic `sitemap.xml`, static `robots.txt`
- PWA: `manifest.json` + `next-pwa` service worker registration
- Supabase schema (`supabase/schema.sql`) with **Row Level Security** for every table used above
- Admin login (Supabase Auth) + dashboard shell with a **fully working "Messages" tab** reading real contact submissions

## 🚧 What's scaffolded (needs a bit more wiring)

These are real, intentional stopping points — building full CRUD screens for every content type would roughly triple this codebase's size, so each is set up to extend quickly rather than faked:

- **Admin dashboard tabs** for Portfolio/Services/Pricing/Blog/Testimonials: the pattern is proven in the Messages tab — copy its `select()` call, add `insert`/`update`/`delete` forms per table (see `supabase/schema.sql` for each table's columns).
- **Website analytics tab**: wire up [Vercel Analytics](https://vercel.com/docs/analytics) or Plausible and surface the numbers here.
- **Downloadable PDF portfolio, Instagram feed, appointment booking UI, quotation request form**: their Supabase tables (`quote_requests`, `appointments`) and `newsletter_subscribers`/storage buckets already exist in `schema.sql` — build the forms/pages the same way `ContactForm.jsx` was built.
- **Offline fallback page** for the PWA: `next-pwa` handles asset caching automatically; add a `public/offline.html` and a custom fallback route if you want a branded "you're offline" screen.
- **Email notifications** on new contact submissions: see the commented-out hook in `app/api/contact/route.js` (drop in Resend, SendGrid, or Supabase Edge Functions + a transactional email provider).

---

## 1. Install dependencies

```bash
npm install
```

## 2. Create your Supabase project

1. Go to [supabase.com](https://supabase.com) → **New project**.
2. Once created, open **SQL Editor** → paste the entire contents of `supabase/schema.sql` → **Run**.
   This creates every table, Row Level Security policy, and the `portfolio`/`avatars` storage buckets.
3. Go to **Project Settings → API** and copy:
   - `Project URL`
   - `anon public` key
   - `service_role` key (keep this secret — server-only)
4. Go to **Authentication → Users → Add user** and create your own admin login (email + password). This is what you'll use at `/admin/login`.

## 3. Configure environment variables

```bash
cp .env.local.example .env.local
```

Fill in:

```
NEXT_PUBLIC_SUPABASE_URL=...
NEXT_PUBLIC_SUPABASE_ANON_KEY=...
SUPABASE_SERVICE_ROLE_KEY=...
NEXT_PUBLIC_SITE_URL=https://yourdomain.com
NEXT_PUBLIC_WHATSAPP_NUMBER=254718029061
```

## 4. Add real content (optional — the site works with sample data out of the box)

Every page tries Supabase first and falls back to the sample content in `lib/data.js` if a table is empty, so you can deploy immediately and fill in real projects, services, pricing, testimonials and blog posts whenever you're ready — either via the Supabase Table Editor directly, or by extending the admin dashboard tabs (see above).

Add your real photo, logo favicon, PWA icons (`public/icons/icon-192.png`, `icon-512.png`), `public/favicon.ico`, and a social share image at `public/og-image.jpg` (1200×630).

## 5. Run locally

```bash
npm run dev
```

Visit `http://localhost:3000`.

## 6. Deploy to Vercel

1. Push this project to a GitHub repository.
2. Go to [vercel.com/new](https://vercel.com/new) and import the repo.
3. Add the same environment variables from `.env.local` in **Project Settings → Environment Variables**.
4. Deploy. Vercel auto-detects Next.js — no extra build config needed.
5. Point your custom domain at the Vercel project (**Settings → Domains**) and update `NEXT_PUBLIC_SITE_URL` to match.
6. After the first deploy, visit `yourdomain.com/sitemap.xml` to confirm it's generating correctly, then submit it in Google Search Console.

## Project structure

```
app/                 → routes (App Router)
  page.js            → Home
  portfolio/         → Portfolio listing + [slug] detail page
  services/          → Services
  pricing/           → Pricing
  about/             → About
  blog/              → Blog listing + [slug] post page
  testimonials/      → Testimonials
  contact/           → Contact
  admin/             → Login + dashboard (excluded from sitemap & robots)
  api/               → contact + newsletter route handlers
components/          → reusable UI (Navbar, Footer, Hero, cards, forms, etc.)
lib/                 → supabaseClient.js (browser), supabaseAdmin.js (server), data.js (fallback content)
supabase/schema.sql  → full DB schema + RLS policies + storage buckets
public/              → manifest.json, robots.txt, icons
```

## Notes on security

- `lib/supabaseAdmin.js` uses the `service_role` key and must **only** be imported from server code (`app/api/**` route handlers or Server Components) — never from a `'use client'` component.
- Row Level Security policies in `schema.sql` currently grant full write access to **any authenticated Supabase user**. If you ever add more logins beyond yourself, add an `is_admin` boolean/claim and tighten the `auth.role() = 'authenticated'` checks to check that claim instead.
